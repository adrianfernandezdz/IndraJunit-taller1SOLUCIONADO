package com.tallerJunitMockTDD.tallerJunitMockTDD;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TallerJunitMockTddApplicationTests {

	@Test
	void contextLoads() {
	}

}
