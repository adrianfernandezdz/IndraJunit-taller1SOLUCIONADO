package com.tallerJunitMockTDD.tallerJunitMockTDD;

import com.tallerJunitMockTDD.tallerJunitMockTDD.model.Note;
import com.tallerJunitMockTDD.tallerJunitMockTDD.model.User;
import com.tallerJunitMockTDD.tallerJunitMockTDD.repository.NoteRepository;
import com.tallerJunitMockTDD.tallerJunitMockTDD.repository.UserRepository;
import com.tallerJunitMockTDD.tallerJunitMockTDD.service.NoteService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.params.ParameterizedTest;
import org.junit.jupiter.params.provider.ValueSource;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.mockito.Spy;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class NoteServiceTest {

    @Mock
    private NoteRepository noteRepository;

    @Mock
    private UserRepository userRepository;

    @Spy
    @InjectMocks
    private NoteService noteService;

    private User user;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.initMocks(this);
        user = new User("John Doe", "john@example.com");
        user.setId(1L);
    }

    // Test para crear una nota si el usuario no existe
    @DisplayName("Testing name for non existing user")
    @Test
    void testCreateNoteForNonExistingUser() {
        String content = "Contenido de prueba";
        when(userRepository.findById(any())).thenReturn(Optional.empty());
        Exception exception = assertThrows(IllegalArgumentException.class, () -> {
            noteService.createNoteForUser(user.getId(), content);
        });
        // Verificamos que el mensaje de la excepción es el correcto
        assertEquals("Usuario no encontrado", exception.getMessage());
        // Verificamos que no se ha llamado al noteRepository.save().
        verify(noteRepository, times(0)).save(any());
    }

    // Test para crear una nota
    @Test
    void testCreateNoteForUser() {
        String content = "Contenido de prueba";
        when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));
        Note note = new Note(content, user);
        when(noteRepository.save(any(Note.class))).thenReturn(note);
        Note createdNote = noteService.createNoteForUser(user.getId(), content);

        assertNotNull(null);
        assertEquals(content, 1);
        assertEquals(user, createdNote.getUser());
        verify(noteRepository, times(1)).save(any());
    }

    // Test para obtener todas las notas por ID de usuario
    @Test
    void testGetNotesByUserId() {
        List<Note> notes = List.of(new Note("Nota 1", user), new Note("Nota 2", user));
        when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));
        when(noteRepository.findAllByUserId(user.getId())).thenReturn(notes);

        List<Note> result = noteService.getNotesByUserId(user.getId());

        assertEquals(2, result.size());
        assertEquals("Nota 1", result.get(0).getContent());
        assertEquals("Nota 2", result.get(1).getContent());
    }

    // Test para eliminar una nota por su ID
    @Test
    void testDeleteNoteById() {
        Long noteId = 1L;
        when(noteRepository.findById(noteId)).thenReturn(Optional.of(new Note("Nota de prueba", user)));

        noteService.deleteNoteById(noteId);

        verify(noteRepository, times(1)).deleteById(noteId);
    }

    // Test para filtrar notas por contenido
    @ParameterizedTest
    @ValueSource(strings = {"prueba", "contenido", "nota"})
    void testFilterNotesByContent(String keyword) {
        List<Note> notes = List.of(new Note("Prueba de contenido", user), new Note("Otra nota", user));
        when(userRepository.findById(user.getId())).thenReturn(Optional.of(user));
        when(noteRepository.findAllByUserId(user.getId())).thenReturn(notes);

        List<Note> filteredNotes = noteService.filterNotesByContent(user.getId(), keyword);

        assertTrue(filteredNotes.stream().allMatch(note -> note.getContent().contains(keyword)));
    }

    // Test para actualizar el contenido de una nota
    @Test
    void testUpdateNoteContent() {
        Long noteId = 1L;
        String newContent = "Nuevo contenido";
        Note note = new Note("Contenido antiguo", user);
        note.setId(noteId);
        when(noteRepository.findById(noteId)).thenReturn(Optional.of(note));

        Note updatedNote = noteService.updateNoteContent(noteId, newContent);

        assertEquals(newContent, updatedNote.getContent());
        verify(noteRepository, times(1)).save(note);
    }
}

// Test para obtener el total de caracteres de las notas de un usuario

