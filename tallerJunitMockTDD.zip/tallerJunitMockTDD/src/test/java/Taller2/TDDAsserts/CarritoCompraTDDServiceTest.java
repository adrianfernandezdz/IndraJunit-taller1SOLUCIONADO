package Taller2.TDDAsserts;

import java.util.HashMap;
import java.util.Map;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class CarritoCompraTDDServiceTest {

    private CarritoCompraTDDService carritoService;

    @BeforeEach

    @Test
    public void testAddProduct() {
    }

    @Test
    public void testRemoveProduct() {
    }

    @Test
    public void testGetTotalProducts() {
    }

    @Test
    public void testCalculateTotal() {
    }

    @Test
    public void testClearCart() {
    }
}
