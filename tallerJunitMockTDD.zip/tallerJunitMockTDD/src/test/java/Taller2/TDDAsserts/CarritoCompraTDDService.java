package Taller2.TDDAsserts;

import java.util.HashMap;
import java.util.Map;

public class CarritoCompraTDDService {

    private Map<String, Integer> cartItems = new HashMap<>(); // Nombre del producto y cantidad

    // Añadir producto al carrito
    public void addProduct(String productName, int quantity) {
    }

    // Eliminar producto del carrito
    public void removeProduct(String productName) {
    }

    // Obtener la cantidad de un producto
    public int getProductQuantity(String productName) {
        return 0;
    }

    // Obtener el total de productos en el carrito
    public int getTotalProducts() {
        return 0;
    }

    // Calcular el costo total del carrito
    public double calculateTotal(Map<String, Double> productPrices) {
        return 0;
    }

    // Vaciar el carrito
    public void clearCart() {
    }
}
