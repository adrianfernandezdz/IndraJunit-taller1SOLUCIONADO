package Taller3.ParameterizedTest.test;

import static org.junit.jupiter.api.Assertions.*;

import Taller3.ParameterizedTest.services.NumberValidatorService;

public class NumberValidatorServiceTest {

    private final NumberValidatorService numberValidatorService = new NumberValidatorService();

    // --- PRUEBAS USANDO @MethodSource ---

    // Test parametrizado para validar el método isPrime con @ParameterizedTest y @MethodSource
    public void testIsPrime(int number) {
        assertTrue(numberValidatorService.isPrime(number), "El número debería ser primo");
    }

    // Test parametrizado para validar el método validateNumberProperties con @ParameterizedTest y @MethodSource
    public void testValidateNumberProperties(int number, boolean expectedIsPrime, boolean expectedIsEven, boolean expectedIsPositive) {
    }

    // --- PRUEBAS USANDO @CsvSource ---

    // Test parametrizado para validar el método isEven con @ParameterizedTest y @CsvSource
    public void testIsEven(int number, boolean expectedIsEven) {
    }

    // Test parametrizado para validar el método isPositive con @ParameterizedTest y @CsvSource
    public void testIsPositive(int number, boolean expectedIsPositive) {
    }
}
