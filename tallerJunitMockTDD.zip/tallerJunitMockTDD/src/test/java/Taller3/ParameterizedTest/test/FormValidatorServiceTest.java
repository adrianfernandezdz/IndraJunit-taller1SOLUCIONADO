package Taller3.ParameterizedTest.test;

import Taller3.ParameterizedTest.services.FormValidatorService;

public class FormValidatorServiceTest {

    FormValidatorService formValidatorService = new FormValidatorService();

    // Test parametrizado para validar nombres usando @ParameterizedTest y @ValueSource
    public void testValidateName(String name) {
    }

    // Test parametrizado para validar edades usando @ParameterizedTest y @ValueSource
    public void testValidateAge(int age) {
    }

    // Test parametrizado para validar correos electrónicos usando @ParameterizedTest y @ValueSource
    public void testValidateEmail(String email) {
    }

    // Test parametrizado para validar contraseñas usando @ParameterizedTest y @ValueSource
    public void testValidatePassword(String password) {
    }

    // Test parametrizado para validar contraseñas usando @ParameterizedTest y @ValueSource

    // Test parametrizado para validar el form usando @ParameterizedTest y @MethodSource
    public void testValidateForm(String name, int age, String email, String password) {
    }
}
