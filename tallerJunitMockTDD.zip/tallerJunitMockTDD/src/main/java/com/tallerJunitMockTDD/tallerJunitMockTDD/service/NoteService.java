package com.tallerJunitMockTDD.tallerJunitMockTDD.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;
import java.util.stream.Collectors;

import com.tallerJunitMockTDD.tallerJunitMockTDD.model.Note;
import com.tallerJunitMockTDD.tallerJunitMockTDD.model.User;
import com.tallerJunitMockTDD.tallerJunitMockTDD.repository.NoteRepository;
import com.tallerJunitMockTDD.tallerJunitMockTDD.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class NoteService {

    @Autowired
    private NoteRepository noteRepository;

    @Autowired
    private UserRepository userRepository;

    /**
     * Crea una nueva nota asociada a un usuario.
     */
    public Note createNoteForUser(Long userId, String content) {
        User user = userRepository.findById(userId).orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));
        validateNoteContent(content);
        Note note = new Note(generateUniqueId(), content, user);
        return noteRepository.save(note);
    }

    /**
     * Obtiene todas las notas de un usuario.
     */
    public List<Note> getNotesByUserId(Long userId) {
        userRepository.findById(userId).orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));
        return noteRepository.findAllByUserId(userId);
    }

    /**
     * Elimina una nota por su ID.
     */
    public void deleteNoteById(Long noteId) {
        noteRepository.findById(noteId).orElseThrow(() -> new IllegalArgumentException("Nota no encontrada"));
        noteRepository.deleteById(noteId);
    }

    /**
     * Filtra las notas de un usuario por un término contenido en el texto.
     */
    public List<Note> filterNotesByContent(Long userId, String keyword) {
        userRepository.findById(userId).orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));
        return noteRepository.findAllByUserId(userId).stream()
                .filter(note -> note.getContent().contains(keyword))
                .collect(Collectors.toList());
    }

    /**
     * Actualiza el contenido de una nota existente.
     */
    public Note updateNoteContent(Long noteId, String newContent) {
        noteRepository.findById(noteId).orElseThrow(() -> new IllegalArgumentException("Nota no encontrada"));
        validateNoteContent(newContent);
        Note note = noteRepository.findById(noteId)
                .orElseThrow(() -> new IllegalArgumentException("Nota no encontrada"));
        note.setContent(newContent);
        return noteRepository.save(note);
    }

    /**
     * Genera un reporte con la cantidad total de caracteres de todas las notas de un usuario.
     */
    public int getTotalCharactersForUser(Long userId) {
        userRepository.findById(userId).orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));
        return noteRepository.findAllByUserId(userId).stream()
                .mapToInt(note -> note.getContent().length())
                .sum();
    }

    /**
     * Obtiene la nota más larga de un usuario.
     */
    public Optional<Note> getLongestNoteForUser(Long userId) {
        userRepository.findById(userId).orElseThrow(() -> new IllegalArgumentException("Usuario no encontrado"));
        return noteRepository.findAllByUserId(userId).stream()
                .max((n1, n2) -> Integer.compare(n1.getContent().length(), n2.getContent().length()));
    }

    /**
     * Valida que el contenido de la nota cumpla con las reglas de longitud.
     */
    private void validateNoteContent(String content) {
        if (content == null || content.length() < 5 || content.length() > 1000) {
            throw new IllegalArgumentException("El contenido de la nota debe tener entre 5 y 1000 caracteres.");
        }
    }

    /**
     * Genera un identificador único para la nota.
     */
    private Long generateUniqueId() {
        return UUID.randomUUID().getMostSignificantBits() & Long.MAX_VALUE;
    }
}