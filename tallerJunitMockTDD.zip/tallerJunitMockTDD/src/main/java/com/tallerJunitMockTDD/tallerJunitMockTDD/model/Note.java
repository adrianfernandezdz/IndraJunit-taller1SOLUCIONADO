package com.tallerJunitMockTDD.tallerJunitMockTDD.model;

import jakarta.persistence.*;

@Entity
public class Note {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private String content;

    @ManyToOne
    @JoinColumn(name = "user_id", nullable = false)
    private User user;

    // Constructor vacío necesario por JPA
    public Note() {}

    public Note(String content, User user) {
        this.content = content;
        this.user = user;
    }

    // Constructor con parámetros
    public Note(Long id, String content, User user) {
        this.id = id;
        this.content = content;
        this.user = user;
    }

    // Getters y setters
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public User getUser() {
        return user;
    }

    public void setUser(User user) {
        this.user = user;
    }
}
