package com.tallerJunitMockTDD.tallerJunitMockTDD.controller;

import java.util.List;
import java.util.Optional;

import com.tallerJunitMockTDD.tallerJunitMockTDD.model.Note;
import com.tallerJunitMockTDD.tallerJunitMockTDD.service.NoteService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/notes")
public class NoteController {

    @Autowired
    private NoteService noteService;

    /**
     * Crea una nueva nota para un usuario.
     */
    @PostMapping("/users/{userId}")
    public ResponseEntity<Note> createNote(@PathVariable Long userId, @RequestBody String content) {
        Note createdNote = noteService.createNoteForUser(userId, content);
        return ResponseEntity.ok(createdNote);
    }

    /**
     * Obtiene todas las notas de un usuario.
     */
    @GetMapping("/users/{userId}")
    public ResponseEntity<List<Note>> getNotesByUserId(@PathVariable Long userId) {
        List<Note> notes = noteService.getNotesByUserId(userId);
        return ResponseEntity.ok(notes);
    }

    /**
     * Actualiza el contenido de una nota existente.
     */
    @PutMapping("/{noteId}")
    public ResponseEntity<Note> updateNote(@PathVariable Long noteId, @RequestBody String newContent) {
        Note updatedNote = noteService.updateNoteContent(noteId, newContent);
        return ResponseEntity.ok(updatedNote);
    }

    /**
     * Elimina una nota por su ID.
     */
    @DeleteMapping("/{noteId}")
    public ResponseEntity<Void> deleteNote(@PathVariable Long noteId) {
        noteService.deleteNoteById(noteId);
        return ResponseEntity.noContent().build();
    }

    /**
     * Filtra las notas de un usuario por contenido.
     */
    @GetMapping("/users/{userId}/filter")
    public ResponseEntity<List<Note>> filterNotes(@PathVariable Long userId, @RequestParam String keyword) {
        List<Note> filteredNotes = noteService.filterNotesByContent(userId, keyword);
        return ResponseEntity.ok(filteredNotes);
    }

    /**
     * Obtiene la nota más larga de un usuario.
     */
    @GetMapping("/users/{userId}/longest")
    public ResponseEntity<Optional<Note>> getLongestNote(@PathVariable Long userId) {
        Optional<Note> longestNote = noteService.getLongestNoteForUser(userId);
        return ResponseEntity.ok(longestNote);
    }

    /**
     * Obtiene la cantidad total de caracteres en las notas de un usuario.
     */
    @GetMapping("/users/{userId}/total-characters")
    public ResponseEntity<Integer> getTotalCharacters(@PathVariable Long userId) {
        int totalCharacters = noteService.getTotalCharactersForUser(userId);
        return ResponseEntity.ok(totalCharacters);
    }
}