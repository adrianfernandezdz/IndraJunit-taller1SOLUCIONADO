package com.tallerJunitMockTDD.tallerJunitMockTDD.service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

import com.tallerJunitMockTDD.tallerJunitMockTDD.model.User;
import com.tallerJunitMockTDD.tallerJunitMockTDD.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;

    /**
     * Retorna todos los usuarios.
     */
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }

    /**
     * Busca un usuario por ID, si no existe retorna un Optional vacío.
     */
    public Optional<User> getUserById(Long id) {
        return userRepository.findById(id);
    }

    /**
     * Crea un usuario nuevo, validando los datos y asignándole un identificador único.
     */
    public User createUser(User user) {
        validateUserData(user);
        user.setId(generateUniqueId());
        return userRepository.save(user);
    }

    /**
     * Elimina un usuario por ID, si existe.
     */
    public void deleteUser(Long id) {
        userRepository.deleteById(id);
    }

    /**
     * Asigna puntos de fidelidad a un usuario en función de su historial.
     */

    // TO-DO: inventarse condiciones par añadir puntos.
    public int assignLoyaltyPoints(User user) {
        int points = calculateBasePoints(user);
        if (user.getEmail().contains(".com")) {
            points += 10; // Bonificación por dominio específico.
        }
        if (user.getName().length() > 5) {
            points += 5; // Bonificación por nombre largo.
        }
        return points;
    }

    /**
     * Método privado para validar los datos del usuario.
     */
    private void validateUserData(User user) {
        if (user.getName() == null || user.getName().isEmpty()) {
            throw new IllegalArgumentException("El nombre no puede estar vacío.");
        }
        if (user.getEmail() == null || !user.getEmail().contains("@")) {
            throw new IllegalArgumentException("Email inválido.");
        }
    }

    /**
     * Calcula los puntos base de fidelidad.
     */
    private int calculateBasePoints(User user) {
        return user.getId() != null ? 100 : 50; // 100 si el usuario ya existía, 50 si es nuevo.
    }

    /**
     * Genera un identificador único para el usuario.
     */
    private Long generateUniqueId() {
        return UUID.randomUUID().getMostSignificantBits() & Long.MAX_VALUE;
    }
}
